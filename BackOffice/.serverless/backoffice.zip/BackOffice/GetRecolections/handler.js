'use strict';
const AWS = require('aws-sdk'); 
const utils = require('common'); 

const dynamoDb = new AWS.DynamoDB.DocumentClient();

module.exports.getRecolections = async (event) => {
    var paramsThreeshold = {
        KeyConditionExpression: '#recover > :threeshold',
        ExpressionAttributeNames: {
            "#recover":"ToRecover",
        },
        ExpressionAttributeValues: {
            ':threeshold': 2400,
        },
        TableName: process.env.DYNAMODB_DON_TABLE
    };
    var paramsDate = {
        KeyConditionExpression: '#lastrecolection > :lastdate',
        ExpressionAttributeNames: {
            "#lastrecolection":"lastrecolection"
        },
        ExpressionAttributeValues: {
            ':lastdate': utils.dateNowDiff(new Date(),-5),
        },
        TableName: process.env.DYNAMODB_DON_TABLE
    };
    const dons = await dynamoDb.query(paramsThreeshold).promise()
    const donsFromDate = await dynamoDb.query(paramsDate).promise()
    return utils.success(dons)
}